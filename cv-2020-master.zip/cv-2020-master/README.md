网页预览：http://fangyinghang.com/cv-2020/dist/index.html

## 开发模式

```
npm i -g parcel-bundler
parcel src/index.html
```

## 部署网页

```
parcel build src/index.html --public-url .
```
